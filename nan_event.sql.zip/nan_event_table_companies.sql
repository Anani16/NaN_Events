
-- --------------------------------------------------------

--
-- Structure de la table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `nom` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `telephone` varchar(8) NOT NULL,
  `adresse` varchar(225) NOT NULL,
  `site_web` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
