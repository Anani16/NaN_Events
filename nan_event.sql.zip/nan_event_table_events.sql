
-- --------------------------------------------------------

--
-- Structure de la table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `titre` varchar(225) NOT NULL,
  `description` text NOT NULL,
  `date_heure` datetime NOT NULL,
  `lien_gmap` varchar(225) NOT NULL,
  `lieu` varchar(225) NOT NULL,
  `prix` int(11) DEFAULT NULL,
  `ville_id` int(11) NOT NULL,
  `commune_id` int(11) DEFAULT NULL,
  `photo` varchar(225) NOT NULL,
  `admin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
