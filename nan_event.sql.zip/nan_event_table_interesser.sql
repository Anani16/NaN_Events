
-- --------------------------------------------------------

--
-- Structure de la table `interesser`
--

CREATE TABLE `interesser` (
  `user_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
